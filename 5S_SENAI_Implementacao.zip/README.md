# 5S SENAI — Implementação Online

## Stack recomendada
- Next.js + TypeScript
- Supabase Auth
- PostgreSQL (Supabase)
- Supabase Storage para fotos
- Recharts para dashboard
- QR Code para identificação dos ambientes

## Como iniciar o banco
1. Crie um projeto no Supabase.
2. Abra SQL Editor.
3. Execute `database/schema.sql`.
4. Crie um bucket privado chamado `5s-evidencias`.
5. Configure autenticação por e-mail/senha.
6. Crie o primeiro usuário no Auth.
7. Cadastre o perfil correspondente na tabela `profiles`.

## Segurança
Antes de uso real, habilite Row Level Security (RLS) em todas as tabelas e crie policies por perfil. Não coloque a `service_role key` no navegador.

## QR Codes
Os identificadores iniciais são:
- 5S-MECANICA
- 5S-AUTOMACAO
- 5S-ELETRICA
- 5S-INFORMATICA
- 5S-SALA-AULA

## Pontuação
Conforme = 1 ponto
Parcial = 0,5 ponto
Não conforme = 0 ponto

Índice 5S = pontos obtidos / pontos possíveis × 100.
