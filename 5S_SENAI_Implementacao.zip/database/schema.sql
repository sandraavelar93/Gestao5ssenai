-- 5S SENAI - Banco PostgreSQL / Supabase
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  email text,
  perfil text not null default 'instrutor'
    check (perfil in ('administrador','instrutor','responsavel')),
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists ambientes (
  id uuid primary key default gen_random_uuid(),
  nome text not null unique,
  setor text,
  qr_codigo text not null unique,
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists sensos (
  id smallserial primary key,
  codigo text not null unique,
  nome text not null unique,
  ordem smallint not null unique
);

create table if not exists checklist_itens (
  id uuid primary key default gen_random_uuid(),
  senso_id smallint not null references sensos(id),
  pergunta text not null,
  peso numeric(6,2) not null default 1,
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists inspecoes (
  id uuid primary key default gen_random_uuid(),
  ambiente_id uuid not null references ambientes(id),
  avaliador_id uuid references profiles(id),
  turma_setor text,
  data_inspecao date not null default current_date,
  pontuacao numeric(5,2) not null default 0,
  conformes integer not null default 0,
  parciais integer not null default 0,
  nao_conformes integer not null default 0,
  observacao text,
  status text not null default 'finalizada'
    check (status in ('rascunho','finalizada','cancelada')),
  created_at timestamptz not null default now()
);

create table if not exists respostas (
  id uuid primary key default gen_random_uuid(),
  inspecao_id uuid not null references inspecoes(id) on delete cascade,
  checklist_item_id uuid not null references checklist_itens(id),
  resultado text not null check (resultado in ('conforme','parcial','nao_conforme')),
  observacao text,
  unique(inspecao_id, checklist_item_id)
);

create table if not exists evidencias (
  id uuid primary key default gen_random_uuid(),
  inspecao_id uuid not null references inspecoes(id) on delete cascade,
  storage_path text not null,
  descricao text,
  created_at timestamptz not null default now()
);

create table if not exists planos_acao (
  id uuid primary key default gen_random_uuid(),
  inspecao_id uuid not null references inspecoes(id) on delete cascade,
  problema text not null,
  acao text not null,
  responsavel text,
  prazo date,
  status text not null default 'pendente'
    check (status in ('pendente','em_andamento','concluida','atrasada')),
  data_conclusao date,
  created_at timestamptz not null default now()
);

insert into ambientes (nome,setor,qr_codigo) values
('Laboratório de Mecânica','Mecânica','5S-MECANICA'),
('Laboratório de Automação','Automação','5S-AUTOMACAO'),
('Laboratório de Elétrica','Elétrica','5S-ELETRICA'),
('Laboratório de Informática','Informática','5S-INFORMATICA'),
('Sala de Aula','Ensino','5S-SALA-AULA')
on conflict (nome) do nothing;

insert into sensos (codigo,nome,ordem) values
('SEIRI','Seiri — Utilização',1),
('SEITON','Seiton — Ordenação',2),
('SEISO','Seiso — Limpeza',3),
('SEIKETSU','Seiketsu — Padronização',4),
('SHITSUKE','Shitsuke — Disciplina',5)
on conflict (codigo) do nothing;

insert into checklist_itens (senso_id, pergunta)
select s.id, x.pergunta
from sensos s
join (values
('SEIRI','Materiais sem uso foram retirados.'),
('SEIRI','Somente materiais necessários permanecem no ambiente.'),
('SEIRI','Materiais quebrados estão segregados para manutenção/descarte.'),
('SEIRI','Não há objetos desnecessários em bancadas, mesas e armários.'),
('SEITON','Ferramentas e equipamentos possuem local definido.'),
('SEITON','Cabos e extensões estão organizados e sem risco de tropeço.'),
('SEITON','Armários, gavetas e prateleiras estão identificados.'),
('SEITON','Materiais de uso frequente estão acessíveis e corretamente guardados.'),
('SEISO','Piso, bancadas e mesas estão limpos.'),
('SEISO','Máquinas, computadores e equipamentos estão limpos.'),
('SEISO','Resíduos estão nos recipientes corretos.'),
('SEISO','Não há óleo, poeira ou sujeira que comprometa a segurança.'),
('SEIKETSU','Procedimentos e padrões de organização estão visíveis.'),
('SEIKETSU','EPIs e orientações de segurança estão sinalizados.'),
('SEIKETSU','Inspeções/checklists estão atualizados.'),
('SEIKETSU','O padrão de organização é mantido por todos.'),
('SHITSUKE','As regras de segurança e organização são cumpridas.'),
('SHITSUKE','Equipamentos são desligados e guardados após o uso.'),
('SHITSUKE','Anomalias são comunicadas ao responsável.'),
('SHITSUKE','A equipe mantém o 5S como hábito diário.')
) as x(codigo,pergunta) on x.codigo=s.codigo
where not exists (
  select 1 from checklist_itens ci
  where ci.senso_id=s.id and ci.pergunta=x.pergunta
);

-- Bucket recomendado no Supabase Storage: 5s-evidencias
-- Para produção, habilite RLS e crie policies de acesso conforme os perfis.
